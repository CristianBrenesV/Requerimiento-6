const http = require('node:http')
const fs = require('node:fs')

const mime = {
  'html': 'text/html',
  'css': 'text/css',
  'jpg': 'image/jpg',
  'jpeg': 'image/jpeg',
  'png': 'image/png',
  'ico': 'image/x-icon',
  'mp3': 'audio/mpeg3',
  'mp4': 'video/mp4'
}

const servidor = http.createServer((pedido, respuesta) => {
  const url = new URL('http://localhost:8088' + pedido.url)
  let camino = 'static' + url.pathname
  if (camino == 'static/')
    camino = 'static/index.html'
  encaminar(pedido, respuesta, camino)
})
servidor.listen(8888)

function encaminar(pedido, respuesta, camino) {
  switch (camino) {
    case 'static/cargar': {
      grabarComentarios(pedido, respuesta)
      break
    }
    case 'static/leercomentarios': {
      leerComentarios(respuesta)
      break
    }
    default: {
      fs.stat(camino, error => {
        if (!error) {
          fs.readFile(camino, (error, contenido) => {
            if (error) {
              respuesta.writeHead(500, { 'Content-Type': 'text/plain' })
              respuesta.write('Error interno')
              respuesta.end()
            } else {
              const vec = camino.split('.')
              const extension = vec[vec.length - 1]
              const mimearchivo = mime[extension]
              respuesta.writeHead(200, { 'Content-Type': mimearchivo })
              respuesta.write(contenido)
              respuesta.end()
            }
          })
        } else {
          respuesta.writeHead(404, { 'Content-Type': 'text/html' })
          respuesta.write('<!doctype html><html><head></head><body>Recurso inexistente</body></html>')
          respuesta.end()
        }
      })
    }
  }
}

function grabarComentarios(pedido, respuesta) {
  let info = ''
  pedido.on('data', datosparciales => {
    info += datosparciales
  });
  pedido.on('end', function () {
    const formulario = new URLSearchParams(info)
    respuesta.writeHead(200, { 'Content-Type': 'text/html' })
    const pagina = `<!doctype html><html><head></head><body>
                 Nombre:${formulario.get('nombre')}<br>
                 Apellidos:${formulario.get('apellidos')}<br>
                 Email:${formulario.get('email')}<br>
                 Telefono:${formulario.get('telefono')}<br>
                 Mensaje:${formulario.get('mensaje')}<hr>
                <a href="index.html">Retornar</a>
                </body></html>`
    respuesta.end(pagina)
    grabarEnArchivo(formulario)
  })
}

function grabarEnArchivo(formulario) {
  const datos = `nombre:${formulario.get('nombre')}<br>
                 apellidos:${formulario.get('apellidos')}<br>
                 email:${formulario.get('email')}<br>
                 telefono:${formulario.get('telefono')}<br>
                 mensaje:${formulario.get('mensaje')}<hr>`
  fs.appendFile('static/MensajesContacto.txt', datos, error => {
    if (error)
      console.log(error)
  })
}

function leerComentarios(respuesta) {
  fs.readFile('static/MensajesContacto.txt', (error, datos) => {
    respuesta.writeHead(200, { 'Content-Type': 'text/html' })
    respuesta.write('<!doctype html><html><head></head><body>')
    respuesta.write(datos)
    respuesta.write('</body></html>')
    respuesta.end()
  })
}

console.log('Servidor web iniciado')