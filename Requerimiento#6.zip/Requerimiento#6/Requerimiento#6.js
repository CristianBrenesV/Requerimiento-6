const http = require('node:http');
const fs = require('node:fs');

const mime = {
  'html': 'text/html',
  'css': 'text/css',
  'jpg': 'image/jpg',
  'jpeg': 'image/jpeg',
  'png': 'image/png',
  'ico': 'image/x-icon',
  'mp3': 'audio/mpeg3',
  'mp4': 'video/mp4'
};

const servidor = http.createServer((pedido, respuesta) => {
  const url = new URL('http://localhost:8888' + pedido.url);
  let camino = 'static' + url.pathname;
  if (camino == 'static/') {
    camino = 'static/index.html';
  }

  encaminar(pedido, respuesta, camino);
});

servidor.listen(8888);

function encaminar(pedido, respuesta, camino) {
  switch (camino) {
    case 'static/cargar': {
      grabarComentarios(pedido, respuesta);
      break;
    }
    case 'static/leercomentarios': {
      leerComentarios(respuesta);
      break;
    }
    case 'static/procesarticket': {
      grabarTickets(pedido, respuesta);
      break;
    }
    case 'static/leerTickets': {
      leerTickets(respuesta);
      break;
    }
    default: {
      servirArchivo(camino, respuesta);
      break;
    }
  }
}

function servirArchivo(camino, respuesta) {
  fs.stat(camino, error => {
    if (!error) {
      fs.readFile(camino, (error, contenido) => {
        if (error) {
          respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
          respuesta.write('Error interno');
          respuesta.end();
        } else {
          const vec = camino.split('.');
          const extension = vec[vec.length - 1];
          const mimearchivo = mime[extension];
          respuesta.writeHead(200, { 'Content-Type': mimearchivo });
          respuesta.write(contenido);
          respuesta.end();
        }
      });
    } else {
      respuesta.writeHead(404, { 'Content-Type': 'text/html' });
      respuesta.write('<!doctype html><html><head></head><body>Recurso inexistente</body></html>');
      respuesta.end();
    }
  });
}

function grabarComentarios(pedido, respuesta) {
  let info = '';
  pedido.on('data', datosparciales => {
    info += datosparciales;
  });
  pedido.on('end', function () {
    const formulario = new URLSearchParams(info);
    respuesta.writeHead(200, { 'Content-Type': 'text/html' });
    const pagina = `<!doctype html><html><head></head><body>
                     Nombre: ${formulario.get('nombre')}<br>
                     Apellidos: ${formulario.get('apellidos')}<br>
                     Email: ${formulario.get('email')}<br>
                     Telefono: ${formulario.get('telefono')}<br>
                     Mensaje: ${formulario.get('mensaje')}<hr>
                     <a href="index.html">Retornar</a>
                     </body></html>`;
    respuesta.end(pagina);
    grabarEnArchivo(formulario, 'static/MensajesContacto.txt');
  });
}

function grabarEnArchivo(formulario, archivo) {
  const datos = `Nombre: ${formulario.get('nombre')}<br>
                 Apellidos: ${formulario.get('apellidos')}<br>
                 Email: ${formulario.get('email')}<br>
                 Telefono: ${formulario.get('telefono')}<br>
                 Mensaje: ${formulario.get('mensaje')}<hr>`;
  
  fs.appendFile(archivo, datos, error => {
    if (error) {
      console.log(error);
    }
  });
}

function leerComentarios(respuesta) {
  fs.readFile('static/MensajesContacto.txt', (error, datos) => {
    if (error) {
      respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
      respuesta.write('Error interno');
      respuesta.end();
    } else {
      respuesta.writeHead(200, { 'Content-Type': 'text/html' });
      respuesta.write('<!doctype html><html><head></head><body>');
      respuesta.write(datos);
      respuesta.write('</body></html>');
      respuesta.end();
    }
  });
}

function grabarTickets(pedido, respuesta) {
  let info = '';
  pedido.on('data', datosparciales => {
    info += datosparciales;
  });
  pedido.on('end', function () {
    const formulario = new URLSearchParams(info);
    respuesta.writeHead(200, { 'Content-Type': 'text/html' });

    // Obtener el precio del formulario
    const precio = formulario.get('precio');

    // Construir la página de respuesta
    const pagina = `<!doctype html><html><head></head><body>
                     EstacionPartida: ${formulario.get('origen')}<br>
                     EstacionLlegada: ${formulario.get('destino')}<br>
                     DiaViaje: ${formulario.get('dia')}<br>
                     HoraViaje: ${formulario.get('hora')}<br>
                     NumBoletos: ${formulario.get('num_boletos')}<br>
                     Precio: ${precio}<hr>
                     <a href="index.html">Retornar</a>
                     </body></html>`;
    respuesta.end(pagina);

    // Guardar en el archivo
    grabarEnArchivotickets(formulario, precio, 'static/Tickets.txt');
  });
}



function grabarEnArchivotickets(formulario, precio, archivo) {
  // Construir los datos a guardar
  const datos = `EstacionPartida: ${formulario.get('origen')}<br>
                 EstacionLlegada: ${formulario.get('destino')}<br>
                 DiaViaje: ${formulario.get('dia')}<br>
                 HoraViaje: ${formulario.get('hora')}<br>
                 NumBoletos: ${formulario.get('num_boletos')}<br>
                 Precio: ${precio}<hr>`;

  // Guardar en el archivo Tickets.txt
  fs.appendFile(archivo, datos, error => {
    if (error) {
      console.log(error);
    }
  });
}

function leerTickets(respuesta) {
  fs.readFile('static/Tickets.txt', (error, datos) => {
    if (error) {
      respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
      respuesta.write('Error interno');
      respuesta.end();
    } else {
      respuesta.writeHead(200, { 'Content-Type': 'text/html' });
      respuesta.write('<!doctype html><html><head></head><body>');
      respuesta.write(datos);
      respuesta.write('</body></html>');
      respuesta.end();
    }
  });
}

console.log('Servidor web iniciado');
